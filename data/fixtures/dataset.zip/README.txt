dataset.zip
WMT 2014 En-De translation subset with train/val/test splits

Scenario: Academic & Scientific Research Assistant — task 98
